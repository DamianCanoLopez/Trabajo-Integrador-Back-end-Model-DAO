package com.dh.trabajoIntegrador.controller;

import com.dh.trabajoIntegrador.model.Paciente;
import com.dh.trabajoIntegrador.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    private PacienteService pacienteService;

    @Autowired
    public PacienteController(PacienteService pacienteService) {
        this.pacienteService = pacienteService;
    }

    /*@GetMapping
    public String buscarPorEmail(Model model, @RequestParam("email") String  email){
        Paciente paciente=pacienteService.buacarXemail(email);
        model.addAttribute("nombre", paciente.getNombre());
        model.addAttribute("apellido",paciente.getApellido());
        //devolver el nombre del template
        return "index";
    }*/

    @GetMapping("/{id}")
    public Paciente buscarPaciente(@PathVariable Integer id){
        return pacienteService.buacarPaciente(id);
    }

    @PostMapping
    public Paciente registarPaciente(@RequestBody Paciente paciente){
        return pacienteService.guardarPaciente(paciente);
    }

    @PutMapping
    public String actualizarPaciente(@RequestBody Paciente paciente){
        //preguntar si existe el paciente
        Paciente buscarpaciente=pacienteService.buacarPaciente(paciente.getId());
        if (buscarpaciente != null){
            pacienteService.actualizarPaciente(paciente);
            return "se actualizo el paciente con id= "+paciente.getId();
        }
        else {
            return "no se puede actualizar el paciente con id= "+paciente.getId()+
                    " ya que no existe en la base de datos";
        }

    }

    @DeleteMapping("/{id}")
    public String eliminarPaciente(@PathVariable Integer id){
        Paciente buscarpaciente=pacienteService.buacarPaciente(id);
        if (buscarpaciente != null){
            pacienteService.eliminarPaciente(id);
            return "se elimino el paciente con id= "+id;
        }
        else {
            return "no se puede eliminar el paciente con id= "+id+
                    " ya que no existe en la base de datos";
        }

    }

    @GetMapping("/all")
    public List<Paciente> buscarTodosLosPacientes(){
        List<Paciente> respuesta =new ArrayList<>();
        return  respuesta=pacienteService.buscarPacientes();
    }

}
